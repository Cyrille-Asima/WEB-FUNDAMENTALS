console.log("page loaded...");


function changeTheText() {
document.getElementById("editprofile"). innerText = 'Cindy Doe'
}

function accept(tod) {
    var element = document.querySelector("#tod")
    element.remove(tod)
}
function remove(tod) {
    var element = document.querySelector("#tod")
    element.remove(tod)
}

function accept2(phi) {
    var element = document.querySelector("#phi")
    element.remove(phi)
}
function remove2(phi) {
    var element = document.querySelector("#phi")
    element.remove(phi)
}