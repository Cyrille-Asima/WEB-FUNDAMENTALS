var button = 3;
var countElement = document.querySelector("#change")
console.log(countElement);

function add() {
    button++;
    countElement.innerText = button + " like(s) " 
    console.log(button);
}


var button2 = 12;
var count2Element = document.querySelector("#change2")
console.log(count2Element);

function add2() {
    button2++;
    count2Element.innerText = button2 + " like(s) " 
    console.log(button2);
}


var button3 = 9;
var count3Element = document.querySelector("#change3")
console.log(count3Element);

function add3() {
    button3++;
    count3Element.innerText = button3 + " like(s) " 
    console.log(button3);
}